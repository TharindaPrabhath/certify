interface AppColor{
    primaryBgClr: string;
    secondaryBgClr: string;
    primaryBrandClr: string;
    secondaryBrandClr: string;
    primaryFontClr: string;
    secondaryFontClr: string;
    primaryErrorClr: string;
    primarySuccesClr: string;
    primaryBlackClr: String;
    dimmedClr: string;
}

export default AppColor;