interface AdminDto{
    id?: number,
    username?: string;
    email?: string,
}

export default AdminDto;