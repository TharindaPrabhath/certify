export enum AdminActionType{
    INITIATE_ADMIN,
    REMOVE_ADMIN
}

export enum UserActionType{
    SET_USER,
    REMOVE_USER
}

export enum CertificateActionType{
    SET_CERTIFICATE,
    REMOVE_CERTIFICATE
}

export enum LoadingActionType{
    SET_LOADING,
    REMOVE_LOADING
}