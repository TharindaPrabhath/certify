import React from "react";

import "./ReportView.css";

const ReportView = () => {
  return (
    <div className="report-view-screen">
      <h1>Hello</h1>
    </div>
  );
};

export default ReportView;
